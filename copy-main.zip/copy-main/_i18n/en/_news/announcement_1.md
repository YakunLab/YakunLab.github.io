A simple inline announcement.
