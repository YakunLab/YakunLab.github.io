---
layout: page
title: titles.publications
description: descriptions.publications
permalink: /publications/
nav: true
nav_order: 1
---
<!-- _pages/publications.md -->
<div class="publications">

{% bibliography -f {{ site.scholar.bibliography }} %}

</div>
