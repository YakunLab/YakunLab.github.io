Um anúncio simples em uma linha.
