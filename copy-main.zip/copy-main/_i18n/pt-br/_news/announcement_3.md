Um anúncio simples em uma linha com Markdown emoji! :sparkles: :smile:
