---
layout: page
title: projects.titles.project3
description: projects.descriptions.project3
img: assets/img/7.jpg
redirect: https://unsplash.com
importance: 3
category: work
---

{% translate_file _projects/3_project.md %}
