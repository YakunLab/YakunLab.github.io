---
layout: news
title: news.titles.news2
date: 2015-11-07 16:11:00-0400
inline: false
related_posts: false
---

{% translate_file _news/announcement_2.md %}
