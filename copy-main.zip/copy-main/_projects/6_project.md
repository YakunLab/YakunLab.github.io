---
layout: page
title: projects.titles.project6
description: projects.descriptions.project6
img:
importance: 4
category: fun
---

{% translate_file _projects/6_project.md %}
