---
layout: page
title: projects.titles.project4
description: projects.descriptions.project4
img:
importance: 3
category: fun
---

{% translate_file _projects/4_project.md %}
