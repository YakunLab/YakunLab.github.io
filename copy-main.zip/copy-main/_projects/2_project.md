---
layout: page
title: projects.titles.project2
description: projects.descriptions.project2
img: assets/img/3.jpg
importance: 2
category: work
giscus_comments: true
---

{% translate_file _projects/2_project.md %}
