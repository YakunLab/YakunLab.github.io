---
layout: page
title: projects.titles.project5
description: projects.descriptions.project5
img: assets/img/1.jpg
importance: 3
category: fun
---

{% translate_file _projects/5_project.md %}
