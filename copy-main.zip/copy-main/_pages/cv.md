---
layout: cv
title: titles.cv
permalink: /cv/
nav: true
nav_order: 4
cv_pdf: example_pdf.pdf
description: descriptions.cv
toc:
  sidebar: left
---
