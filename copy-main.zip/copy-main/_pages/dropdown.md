---
layout: page
title: titles.submenus
nav: true
nav_order: 7
dropdown: true
children:
    - title: titles.publications
      permalink: /publications/
    - title: divider
    - title: titles.projects
      permalink: /projects/
---
