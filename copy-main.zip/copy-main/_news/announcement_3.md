---
layout: news
title: news.titles.news3
date: 2016-01-15 07:59:00-0400
inline: true
related_posts: false
---

{% translate_file _news/announcement_3.md %}
