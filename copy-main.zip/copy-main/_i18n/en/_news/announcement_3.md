A simple inline announcement with Markdown emoji! :sparkles: :smile:
