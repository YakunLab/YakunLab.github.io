---
layout: page
title: projects.titles.project1
description: projects.descriptions.project1
img: assets/img/12.jpg
importance: 1
category: work
related_publications: einstein1956investigations, einstein1950meaning
---

{% translate_file _projects/1_project.md %}
